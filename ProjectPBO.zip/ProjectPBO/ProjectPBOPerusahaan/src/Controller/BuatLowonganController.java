package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import utils.helpers;

public class BuatLowonganController extends helpers {

    @FXML
    private Button Button;

    @FXML
    void BuatLowongan(ActionEvent event) {
        ChangePage(event, "BuatLowongan");
    }

    @FXML
    void DataPerusahaan(ActionEvent event) {
        ChangePage(event, "DataPerusahaan");

    }

    @FXML
    void TambahLowongan(ActionEvent event) {
        ChangePage(event, "TambahLowongan");
    }

    @FXML
    void Lamaran(ActionEvent event) {
        ChangePage(event, "Lamaran");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");

    }
}