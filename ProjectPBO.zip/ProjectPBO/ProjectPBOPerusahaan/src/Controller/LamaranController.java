package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import utils.helpers;

public class LamaranController extends helpers {

    @FXML
    private Button Button;

    @FXML
    void BuatLowongan(ActionEvent event) {
        ChangePage(event, "BuatLowongan");
    }

    @FXML
    void DataPerusahaan(ActionEvent event) {
        ChangePage(event, "DataPerusahaan");

    }

    @FXML
    void Lamaran(ActionEvent event) {
        ChangePage(event, "Lamaran");

    }

    @FXML
    void LihatPelamar1(ActionEvent event) {
        ChangePage(event, "LihatPelamar1");

    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");

    }
}