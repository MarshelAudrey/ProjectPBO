-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2020 at 11:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobdesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `aduan`
--

CREATE TABLE `aduan` (
  `id_aduan` int(11) NOT NULL,
  `nib` int(11) DEFAULT NULL,
  `nik` int(11) DEFAULT NULL,
  `pesanaduan` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `dataperusahaan`
--

CREATE TABLE `dataperusahaan` (
  `nib` int(30) NOT NULL,
  `namaperusahaan` varchar(20) DEFAULT NULL,
  `badanhukum` varchar(10) DEFAULT NULL,
  `alamatkantor` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dataperusahaan`
--

INSERT INTO `dataperusahaan` (`nib`, `namaperusahaan`, `badanhukum`, `alamatkantor`, `email`, `password`) VALUES
(1234567890, 'Bima Surya', 'PT', 'JL. Meong', 'taktahu@gmail.com', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `datauser`
--

CREATE TABLE `datauser` (
  `nik` int(20) NOT NULL,
  `no.kk` int(20) DEFAULT NULL,
  `nama_user` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `hasillamaran`
--

CREATE TABLE `hasillamaran` (
  `id_hasillamaran` int(11) NOT NULL,
  `id_lamaran` int(11) DEFAULT NULL,
  `statuslamaran` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lamaran`
--

CREATE TABLE `lamaran` (
  `id_lamaran` int(11) NOT NULL,
  `nik` int(11) DEFAULT NULL,
  `nib` int(11) DEFAULT NULL,
  `id_lowongankerja` int(11) DEFAULT NULL,
  `cv` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lowongankerja`
--

CREATE TABLE `lowongankerja` (
  `id_lowongankerja` int(11) NOT NULL,
  `jenispekerjaan` varchar(30) DEFAULT NULL,
  `kisaran gaji` int(10) DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL,
  `nib` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pusatinformasi`
--

CREATE TABLE `pusatinformasi` (
  `id_pusatinformasi` int(11) NOT NULL,
  `judul` varchar(40) DEFAULT NULL,
  `acara` varchar(20) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `waktu` time(6) DEFAULT NULL,
  `tempat` varchar(20) DEFAULT NULL,
  `deskripsi` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tanggapan`
--

CREATE TABLE `tanggapan` (
  `id_tanggapan` int(11) NOT NULL,
  `id_aduan` int(11) DEFAULT NULL,
  `nik` int(11) DEFAULT NULL,
  `tanggapan` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aduan`
--
ALTER TABLE `aduan`
  ADD PRIMARY KEY (`id_aduan`),
  ADD KEY `nib` (`nib`),
  ADD KEY `nik` (`nik`) USING BTREE;

--
-- Indexes for table `dataperusahaan`
--
ALTER TABLE `dataperusahaan`
  ADD PRIMARY KEY (`nib`);

--
-- Indexes for table `datauser`
--
ALTER TABLE `datauser`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `hasillamaran`
--
ALTER TABLE `hasillamaran`
  ADD PRIMARY KEY (`id_hasillamaran`),
  ADD KEY `id_lamaran` (`id_lamaran`);

--
-- Indexes for table `lamaran`
--
ALTER TABLE `lamaran`
  ADD PRIMARY KEY (`id_lamaran`),
  ADD KEY `nik` (`nik`),
  ADD KEY `nib` (`nib`),
  ADD KEY `id_lowongankerja` (`id_lowongankerja`);

--
-- Indexes for table `lowongankerja`
--
ALTER TABLE `lowongankerja`
  ADD PRIMARY KEY (`id_lowongankerja`),
  ADD KEY `nib` (`nib`);

--
-- Indexes for table `pusatinformasi`
--
ALTER TABLE `pusatinformasi`
  ADD PRIMARY KEY (`id_pusatinformasi`);

--
-- Indexes for table `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD PRIMARY KEY (`id_tanggapan`),
  ADD KEY `id_aduan` (`id_aduan`),
  ADD KEY `nik` (`nik`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aduan`
--
ALTER TABLE `aduan`
  MODIFY `id_aduan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hasillamaran`
--
ALTER TABLE `hasillamaran`
  MODIFY `id_hasillamaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lamaran`
--
ALTER TABLE `lamaran`
  MODIFY `id_lamaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lowongankerja`
--
ALTER TABLE `lowongankerja`
  MODIFY `id_lowongankerja` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pusatinformasi`
--
ALTER TABLE `pusatinformasi`
  MODIFY `id_pusatinformasi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tanggapan`
--
ALTER TABLE `tanggapan`
  MODIFY `id_tanggapan` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aduan`
--
ALTER TABLE `aduan`
  ADD CONSTRAINT `fk_aduan` FOREIGN KEY (`nib`) REFERENCES `dataperusahaan` (`nib`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hasillamaran`
--
ALTER TABLE `hasillamaran`
  ADD CONSTRAINT `fk_hasillamaran` FOREIGN KEY (`id_lamaran`) REFERENCES `lamaran` (`id_lamaran`);

--
-- Constraints for table `lamaran`
--
ALTER TABLE `lamaran`
  ADD CONSTRAINT `fk_lamaran` FOREIGN KEY (`id_lowongankerja`) REFERENCES `lowongankerja` (`id_lowongankerja`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lamaran_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `datauser` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lamaran_ibfk_2` FOREIGN KEY (`nib`) REFERENCES `dataperusahaan` (`nib`);

--
-- Constraints for table `pusatinformasi`
--
ALTER TABLE `pusatinformasi`
  ADD CONSTRAINT `pusatinformasi_ibfk_1` FOREIGN KEY (`id_pusatinformasi`) REFERENCES `datauser` (`nik`);

--
-- Constraints for table `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD CONSTRAINT `fk_tanggapan` FOREIGN KEY (`id_aduan`) REFERENCES `aduan` (`id_aduan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
