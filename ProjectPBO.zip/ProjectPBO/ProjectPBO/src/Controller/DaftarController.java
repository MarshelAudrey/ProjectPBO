package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import utils.helpers;

public class DaftarController extends helpers {

  @FXML
    private TextField tfusername;

    @FXML
    private Label username;

    @FXML
    private TextField tfPassword;

    @FXML
    private Label Password;

    @FXML
    private TextField tfPassword1;

    @FXML
    public void DaftarButton(ActionEvent event)  {
      ChangePage(event, "User");
    }

    @FXML
    public void Kelogin (ActionEvent event) {
      ChangePage(event, "Login");
    }


  }
