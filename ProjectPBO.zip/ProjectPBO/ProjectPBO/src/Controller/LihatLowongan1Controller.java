package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import utils.helpers;

public class LihatLowongan1Controller extends helpers {


    @FXML
    private javafx.scene.control.Button Button;

    @FXML
    void Aduan(ActionEvent event) {
        ChangePage(event, "Aduan");
    }

    @FXML
    void Akun(ActionEvent event) {
        ChangePage(event, "User");
    }

    @FXML
    void Hasil(ActionEvent event){
        ChangePage(event, "Hasil");
    }

    @FXML
    void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    void lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

    @FXML
    void KirimLamaran(ActionEvent event) {
        ChangePage(event, "Hasil");
    }
}
