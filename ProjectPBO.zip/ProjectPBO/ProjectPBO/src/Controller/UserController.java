package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import utils.helpers;

public class UserController extends helpers {

    @FXML
    public void Aduan(ActionEvent event) { ChangePage(event, "Aduan"); }

    @FXML
    public void Akun(ActionEvent event) {
        ChangePage(event, "Akun");
    }

    @FXML
    public void Hasil(ActionEvent event){
        ChangePage(event, "Hasil");
    }

    @FXML
    public void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    public void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    public void Lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

}
