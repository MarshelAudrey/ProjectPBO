package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import utils.helpers;

public class LihatBerita1Controller extends helpers {


    @FXML
    void Aduan(ActionEvent event) {
        ChangePage(event, "Aduan");
    }

    @FXML
    void Akun(ActionEvent event) {
        ChangePage(event, "User");
    }

    @FXML
    void Hasil(ActionEvent event){
        ChangePage(event, "Hasil");
    }

    @FXML
    void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    void lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

    @FXML
    void KePusatInformasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }
}
