package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import utils.helpers;

public class HasilController extends helpers {

    @FXML
    private Button Button;
    @FXML
    void Aduan(ActionEvent event) {
        ChangePage(event, "Aduan");
    }

    @FXML
    void Akun(ActionEvent event) {
        ChangePage(event, "User");
    }

    @FXML
    void Hasil(ActionEvent event){
        ChangePage(event, "Hasil");
    }

    @FXML
    void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    void lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

    @FXML
    void LihatLamaran1(ActionEvent event) {
        ChangePage(event, "LihatLowongan1");
    }
}
