package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import utils.helpers;

public class Controller extends helpers{


    @FXML
    private TextField tfusername;

    @FXML
    private Label username;

    @FXML
    private TextField tfPassword;

    @FXML
    private Label Password;

    @FXML
    public void Daftar(ActionEvent event) {
        ChangePage(event, "Daftar");
    }


    @FXML
    public void LoginButton (ActionEvent event) {
        if (tfusername.getText().equals("user") && tfPassword.getText().equals("1234")){
            System.out.println("login Berhasil");
            ChangePage(event, "User");
        }
        else {
            System.out.println("Login Gagal");
        }
    }

}