package Controller;

import Models.Post;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import utils.helpers;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AduanController extends helpers implements Initializable {

    @FXML
    private Button Button;

    @FXML
    private ListView <String> listPost;

   @Override
    public void initialize(URL location, ResourceBundle resources){
        List<Post> posts = Post.getAllPost();
        for (Post p : posts){
            listPost.getItems().add(p.getTitle());
        }
    }

    @FXML
    void Aduan(ActionEvent event) {
        ChangePage(event, "Aduan");
    }

    @FXML
    void Akun(ActionEvent event) {
        ChangePage(event, "User");
    }

    @FXML
    void Hasil(ActionEvent event){
        ChangePage(event, "Hasil");
    }

    @FXML
    void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    void lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

    @FXML
    void KeTambahAduan(ActionEvent event) {
        ChangePage(event, "TambahAduan");

    }
}
