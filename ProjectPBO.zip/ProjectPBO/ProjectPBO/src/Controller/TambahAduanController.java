package Controller;

import Models.Post;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import utils.helpers;

public class TambahAduanController extends helpers {



    @FXML
    private Button Button;

    @FXML
    private TextField judulField;

    @FXML
    private Button addButton;

    @FXML
    void Aduan(ActionEvent event) {
        ChangePage(event, "Aduan");
    }

    @FXML
    void Akun(ActionEvent event) {
        ChangePage(event, "User");
    }

    @FXML
    void Hasil(ActionEvent event) { ChangePage(event, "Hasil"); }

    @FXML
    void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

    @FXML
    void lowongan(ActionEvent event) {
        ChangePage(event, "Lowongan");
    }

    @FXML
    void TambahAduan(ActionEvent event) {
        String title = judulField.getText();
        Post.add(title);
        ChangePage(event, "Aduan");
    }
}
