package Models;

import Main.DBConnection;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class DBHelper {
    public abstract String table();
    public Object _class(){
        return this;
    }

    public abstract String[] columns();

    public String id() {
        return "id";
    }

    public Object findData(String id){
        try {
            return this.getAllData("WHERE id = " + id).get(0);
        } catch (Exception e){
            return null;
        }
    }

    public List<Object> getAllData(String condition) {
        List<Object> results = new ArrayList<>();
        ResultSet resultSet = execute("SELECT * FROM " + table() + " " + condition);
        try {
            while (resultSet.next()){
                Object o = Class.forName(_class().getClass().getName()).newInstance();
                for(String column : columns()){
                    Method m = o.getClass().getDeclaredMethod("set" + capitalize(column), String.class);
                    m.invoke(o, resultSet.getString(column));
                }
                results.add(o);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return results;
    }

    public boolean insert(Map<String, String> params){
        String columns = table() + "(";
        String values = "VALUES(";
        for(String key : params.keySet()){
            columns += String.format("%s,", key);
        }
        columns = columns.substring(0, columns.length() - 1);
        columns += ") ";

        for(String val : params.values()){
            values += String.format("\"%s\",", val);
        }
        values = values.substring(0, values.length() - 1);
        values += ") ";

        String sql = "INSERT INTO " + columns + values;
        System.out.println(sql);
        try {
            Statement statement = DBConnection.connectDB().createStatement();
            return statement.executeUpdate(sql) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private ResultSet execute(String query) {
        Connection connection = DBConnection.connectDB();
        ResultSet resultSet = null;
        try {
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return resultSet;
    }
    public String capitalize(String s){
        return s.substring(0,1).toUpperCase() + s.substring(1,s.length()).toLowerCase();
    }
}
