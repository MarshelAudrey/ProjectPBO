package Models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Post extends DBHelper{
    private String id, title, text;
    private static final Post post = new Post();

    @Override
    public String table() {
        return "posts";
    }

    @Override
    public String[] columns() {
        return new String[]{"id", "title", "text"};
    }

    public Post () {

    }
    public static List<Post> getAllPost(){
        List<Post> data = new ArrayList<>();
        List<Object> results = post.getAllData("" );
        for (Object o : results){
            data.add((Post) o);

        }
        return data;

    }
    public static boolean add(String title){
        Map<String, String> params = new HashMap<String, String>();
        params.put("title", title.replaceAll("\"", "\"\""));
//        params.put("text", text.replaceAll("\"", "\"\""));
        return post.insert(params);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
