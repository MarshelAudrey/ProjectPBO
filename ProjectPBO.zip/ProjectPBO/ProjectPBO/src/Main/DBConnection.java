package Main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    Connection connection = null;
    public static final String DBMS = "mysql";
    public static final String HOST = "127.0.0.1";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public static final String DATABASE = "aduan";

    public static Connection connectDB(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = String.format("jdbc:%s://%s/%s", DBMS, HOST, DATABASE);
            Connection conn = DriverManager.getConnection(url, USERNAME, PASSWORD);
            return conn;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}