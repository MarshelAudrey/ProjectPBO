package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import utils.helpers;

public class DataPenggunaController extends helpers {

    @FXML
    private javafx.scene.control.Button Button;

    @FXML
    void DataAduan(ActionEvent event) {
        ChangePage(event, "DataAduan");
    }

    @FXML
    void DataLowongan(ActionEvent event) {
        ChangePage(event, "DataLowongan");
    }

    @FXML
    void DataPengguna(ActionEvent event) {
        ChangePage(event, "DataPengguna");
    }

    @FXML
    void DataPerusahaan(ActionEvent event) {
        ChangePage(event, "DataPerusahaan");
    }

    @FXML
    public void Informasi(ActionEvent event) {
        ChangePage(event, "Informasi");
    }

    @FXML
    public void Logout(ActionEvent event) {
        ChangePage(event, "Login");
    }

}
