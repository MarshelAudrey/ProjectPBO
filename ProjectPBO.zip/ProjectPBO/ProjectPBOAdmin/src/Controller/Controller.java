package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import utils.helpers;

public class Controller extends helpers{

    @FXML
    private Button Button;

    @FXML
    private TextField tfusername;

    @FXML
    private Label username;

    @FXML
    private TextField tfPassword;

    @FXML
    private Label Password;

    @FXML
    public void LoginButton (ActionEvent event) {
        if (tfusername.getText().equals("Admin") && tfPassword.getText().equals("1234")){
            System.out.println("login Berhasil");
            ChangePage(event, "DataLowongan");
        }
        else {
            System.out.println("Login Gagal");
        }
    }

}